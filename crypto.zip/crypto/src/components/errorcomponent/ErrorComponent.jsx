import React from 'react'

const ErrorComponent = () => {
  return (
    <div>ErrorComponent</div>
  )
}

export default ErrorComponent